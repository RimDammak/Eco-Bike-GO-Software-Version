/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Entite.Event;
import Entite.Reserv;
import Entite.User;
import Service.ServiceEvent;
import Service.ServiceReserv;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import utile.DataSource;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.encoder.ByteMatrix;
import com.google.zxing.qrcode.encoder.QRCode;

import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import java.util.HashMap;
import java.util.Map;




/**
 * FXML Controller class
 *
 * @author choua
 */
public class InterfaceConsulterEventController implements Initializable {

    @FXML
    private TextField id_event_field;
    @FXML
    private TextField id_client_field;
    @FXML
    private TextField chercher_fiel;
    @FXML
    private TableView<Reserv> T_Reservation;
    @FXML
    private TableColumn<Reserv, Integer> T_Reservation_id;
    @FXML
    private TableColumn<Reserv, Integer> Tservation_idevent_Re;
    @FXML
    private TableColumn<Reserv, Integer> T_Reservation_idclient;
    
       @FXML
    private Button code;
       
        private int userId;
    private int eventId;

private int idUser;
private int idEvent;
   
     private Connection conn = DataSource.getInstance().getcnx();
   private ServiceReserv sr = new ServiceReserv();
   private ObservableList<Reserv> reservList = FXCollections.observableArrayList();


    /**
     * Initializes the controller class.
     */
   
   
@Override
public void initialize(URL url, ResourceBundle rb) {
    
    
   T_Reservation_id.setCellValueFactory(new PropertyValueFactory<>("id_res"));
Tservation_idevent_Re.setCellValueFactory(new PropertyValueFactory<>("ev"));

T_Reservation_idclient.setCellValueFactory(new PropertyValueFactory<>("u"));





   reservList.setAll(getListeReservations());
   T_Reservation.setItems(reservList);
}
 
public ObservableList<Reserv> getListeReservations() {
    ServiceReserv sr = new ServiceReserv();
    List<Reserv> reservations = sr.afficherReservation();

   for (Reserv reserv : reservations) {
        // Récupération de l'événement associé à la réservation
        ServiceEvent se = new ServiceEvent();
        Event event = se.getEventById(reserv.getEv().getId_event());
        reserv.setEv(event);

    }

    return FXCollections.observableArrayList(reservations);
}

    @FXML
 private void Reserv_Ajouter(ActionEvent event) {
    int id_event = Integer.parseInt(id_event_field.getText());
    int id_client = Integer.parseInt(id_client_field.getText());
    
    // Vérifier la disponibilité des places
    String requete = "SELECT dispoplace_event FROM event WHERE id_event = ?";
    try {
        PreparedStatement pst = conn.prepareStatement(requete);
        pst.setInt(1, id_event);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            int nbDispoPlace = rs.getInt("dispoplace_event");
            if (nbDispoPlace == 0) {
                // Afficher un message d'erreur
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Erreur");
                alert.setHeaderText(null);
                alert.setContentText("Il n'y a plus de places disponibles pour cet événement.");
                alert.showAndWait();
                return;
            }
        } else {
            // Afficher un message d'erreur
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText(null);
            alert.setContentText("L'événement avec l'ID spécifié n'a pas été trouvé.");
            alert.showAndWait();
            return;
        }
    } catch (SQLException ex) {
        Logger.getLogger(ServiceReserv.class.getName()).log(Level.SEVERE, null, ex);
        // Afficher un message d'erreur
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erreur");
        alert.setHeaderText(null);
        alert.setContentText("Une erreur est survenue lors de la vérification de la disponibilité des places.");
        alert.showAndWait();
        return;
    }
    
    // Ajouter la réservation
    ServiceReserv sr = new ServiceReserv();
    Reserv reservation = sr.getReservation(id_event, id_client);
    
    if (reservation != null) {
        // Afficher un message de succès
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText("Reservation added successfully!");
        alert.showAndWait();
        id_event_field.clear();
        id_client_field.clear();
        T_Reservation.refresh();
        T_Reservation.setItems(reservList);
    } else {
        // Afficher un message d'erreur
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erreur");
        alert.setHeaderText(null);
        alert.setContentText("Impossible de créer la réservation.");
        alert.showAndWait();
    }
}


    @FXML
    private void Supp_Reserv(ActionEvent event) {
        Reserv r1= new Reserv();
        r1.setId_res(Integer.parseInt(chercher_fiel.getText()));
        ServiceReserv sr = new ServiceReserv();
        sr.annulerLaReservation(r1.getId_res());
        
         Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText("Reservation Deleted successfully!");
        alert.showAndWait();
        id_event_field.clear();
        id_client_field.clear();
          T_Reservation.refresh();
       T_Reservation.setItems(reservList);
    }

    @FXML
    private void cherch(ActionEvent event) {
  String requette = "select id_event ,IdUser  from reser where 	id_res  ='"+Integer.parseInt(chercher_fiel.getText())+"'";
    try{
       
        PreparedStatement pst = conn.prepareStatement(requette); 
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
         
            
            idEvent = rs.getInt("id_event");
            id_event_field.setText(String.valueOf(idEvent));
            
            idUser = rs.getInt("IdUser");
            id_client_field.setText(String.valueOf(idUser));
            
          
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
        
        
    }
    
     @FXML

private void PressQrCode(ActionEvent event) {
    // Récupération de toutes les réservations
    ObservableList<Reserv> reservations = getListeReservations();

    // Boucle à travers toutes les réservations et générer un code QR pour chacune
    for (Reserv reserv : reservations) {
        // Construction du texte à encoder dans le code QR en utilisant les détails de la réservation
       // String qrCodeText = + "Id de User est : " +reserv.getU().getIdUser() + " et l'id de l'evenemnt est : " + reserv.getEv().getId_event();
       String qrCodeText = "Id de User est : " + reserv.getU().getIdUser() + " et l'id de l'evenemnt est : " + reserv.getEv().getId_event();


        // Taille du QR code
        int size = 250;

        // Type de fichier (png, jpg, etc.)
        String fileType = "png";

        // Nom du fichier de sortie
        String fileName = "qrcode_" + reserv.getId_res() + "." + fileType;

        // Génération du QR code
        File qrFile = new File(fileName);
        try {
            createQRCode(qrFile, qrCodeText, size, fileType);
        } catch (WriterException | IOException ex) {
            // Gestion de l'exception
            ex.printStackTrace();
            return;
        }

        // Affichage du QR code dans une nouvelle fenêtre
        Stage stage = new Stage();
        stage.setTitle("QR Code for Reservation #" + reserv.getId_res());

        // Création de l'imageview pour afficher le QR code
        ImageView imageView = new ImageView();
        try {
            Image qrImage = new Image(qrFile.toURI().toURL().toExternalForm());
            imageView.setImage(qrImage);
            imageView.setFitWidth(size);
            imageView.setFitHeight(size);
        } catch (MalformedURLException ex) {
            // Gestion de l'exception
            ex.printStackTrace();
            return;
        }

        // Création d'un pane pour la disposition de l'imageview
        Pane pane = new Pane();
        pane.getChildren().add(imageView);

        // Création de la scène et ajout du pane
        Scene scene = new Scene(pane);
        stage.setScene(scene);

        // Affichage de la nouvelle fenêtre
        stage.show();
    }
}



  
  private void createQRCode(File qrFile, String qrCodeText, int size, String fileType)
        throws WriterException, IOException {
    // Création du contenu pour le QR code
    Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<>();
    hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
    QRCodeWriter qrCodeWriter = new QRCodeWriter();
    BitMatrix bitMatrix = qrCodeWriter.encode(qrCodeText, BarcodeFormat.QR_CODE, size, size, hintMap);

    // Conversion de la matrice en image
    BufferedImage qrImage = MatrixToImageWriter.toBufferedImage(bitMatrix);

    // Enregistrement de l'image
    ImageIO.write(qrImage, fileType, qrFile);
}
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Entite.Event;
import Entite.Reserv;
import Entite.User;
import Service.ServiceEvent;
import Service.ServiceReserv;
import com.jfoenix.controls.JFXButton;
import java.awt.Insets;
import java.io.File;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import java.awt.*;




/**
 * FXML Controller class
 *
 * @author choua
 */
public class InterfaceUserEventController implements Initializable {

    @FXML
    private ScrollPane eventPane;
    @FXML
    private HBox categoriesHBox;
    @FXML
    private JFXButton addBtn;
    @FXML
    private Pagination pagination;
    
    private List<Event> eventsList;

        
        
     ServiceEvent SE = new ServiceEvent();

    /**
     * Initializes the controller class.
     */
    @Override
 public void initialize(URL url, ResourceBundle rb) {
    try {
        eventsList = SE.readAll();
        // Afficher la liste des événements
        showEventsList(eventsList);
    
    } catch (Exception e) {
        e.printStackTrace();
    }
}
 
private void showEventsList(List<Event> events) {
    categoriesHBox.getChildren().clear();
     for (Event event : events) {
        AnchorPane eventPane = new AnchorPane();
        eventPane.setPrefSize(300, 200);
        ImageView imageView = new ImageView();
        imageView.setFitHeight(200);
        imageView.setFitWidth(200);
        
        Image image = new Image(new File(event.getPhoto_event()).toURI().toString());
        imageView.setImage(image);
        
        Label nameLabel = new Label(event.getNom_event());
        nameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 18px;");
        
        Label locationLabel = new Label("Location: " + event.getLocate_event());
        Label availabilityLabel = new Label("Availability: " + event.getDispoplace_event());
        
        VBox eventInfoBox = new VBox();
        eventInfoBox.getChildren().addAll(nameLabel, locationLabel, availabilityLabel, imageView);
             
        Button reserveBtn = new Button("Réserver");
        Label statusLabel = new Label("");
        HBox buttonBox = new HBox(reserveBtn, statusLabel);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);

        reserveBtn.setOnAction(e -> {
            User user = new User();
            user.setIdUser(6);
            ServiceReserv serviceReserv = new ServiceReserv();
         //   Reserv reservation = serviceReserv.getReservation(event.getId_event(), 6);

            // Mettre à jour la liste des événements localement
            for (Event ev : eventsList) {
                if (ev.getId_event() == event.getId_event()) {
                    ev.setDispoplace_event(ev.getDispoplace_event() - 1);
                    break;
                }
            }

            // Ajouter la réservation
            boolean success = serviceReserv.getReservation(event.getId_event(), 6) != null;

            // Afficher le message de succès ou de refus
            if (success) {
                // Réservation réussie
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Réservation réussie");
                alert.setHeaderText(null);
                alert.setContentText("Votre réservation a été enregistrée avec succès.");
                alert.showAndWait();
            } else {
                // Réservation refusée
                Alert alert = new Alert(AlertType.WARNING);
                alert.setTitle("Réservation refusée");
                alert.setHeaderText(null);
                alert.setContentText("La réservation a échoué. Veuillez réessayer plus tard.");
                alert.showAndWait();
            }

            // Actualiser la vue pour refléter les changements
            showEventsList(eventsList);
        });

        VBox eventBox = new VBox();
        eventBox.getChildren().addAll(eventInfoBox, buttonBox);

        eventPane.getChildren().add(eventBox);
        categoriesHBox.getChildren().add(eventPane);
    }
}










    
    
    

    @FXML
    private void showAllCategoriesAction(MouseEvent event) {
        System.out.println("test");
    }

    @FXML
    private void addEventAction(ActionEvent event) {
    }
    
}

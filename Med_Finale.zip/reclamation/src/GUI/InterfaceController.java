/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author choua
 */
public class InterfaceController implements Initializable {

    @FXML
    private Button btnUser;
    @FXML
    private Button btnVelo;
    @FXML
    private Button btnStation;
    @FXML
    private Button btnEvent;
    @FXML
    private Button btnRec;
    @FXML
    private Button userbut;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void userclic(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader(getClass().getResource("InterfaceUser.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage=new Stage();
        stage.setScene(scene);
           stage.setTitle("Gestion User");
        stage.show();
    }

    @FXML
    private void clicvelo(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader(getClass().getResource("InterfaceVelo.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage=new Stage();
              stage.setTitle("Gestion Vélos");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void clicstation(ActionEvent event) throws IOException {
          FXMLLoader loader = new FXMLLoader(getClass().getResource("InterfaceStation.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage=new Stage();
              stage.setTitle("Gestion Stations");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void clicevent(ActionEvent event) throws IOException {
         FXMLLoader loader = new FXMLLoader(getClass().getResource("InterfaceEvent.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage=new Stage();
              stage.setTitle("Gestion Evenements");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void clicrec(ActionEvent event) throws IOException {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("InterfaceReclamation.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        
        Stage stage=new Stage();
              stage.setTitle("Gestion Réclamations");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void userbut(ActionEvent event) throws IOException {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("InterfaceUserEvent.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        
        Stage stage=new Stage();
              stage.setTitle("Interface User");
        stage.setScene(scene);
        stage.show();
    }
    
}

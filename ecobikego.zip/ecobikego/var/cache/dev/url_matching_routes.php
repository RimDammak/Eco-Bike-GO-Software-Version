<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/categorie' => [[['_route' => 'app_categorie_index', '_controller' => 'App\\Controller\\CategorieController::index'], null, ['GET' => 0], null, true, false, null]],
        '/categorie/new' => [[['_route' => 'app_categorie_new', '_controller' => 'App\\Controller\\CategorieController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/hassen' => [[['_route' => 'app_hassen', '_controller' => 'App\\Controller\\HassenController::index'], null, null, null, false, false, null]],
        '/houssem' => [[['_route' => 'app_houssem', '_controller' => 'App\\Controller\\HassenController::houssem'], null, null, null, false, false, null]],
        '/velo' => [[['_route' => 'app_velo_index', '_controller' => 'App\\Controller\\VeloController::index'], null, ['GET' => 0], null, true, false, null]],
        '/velo/new' => [[['_route' => 'app_velo_new', '_controller' => 'App\\Controller\\VeloController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/categorie/([^/]++)(?'
                    .'|(*:29)'
                    .'|/edit(*:41)'
                    .'|(*:48)'
                .')'
                .'|/velo/([^/]++)(?'
                    .'|(*:73)'
                    .'|/edit(*:85)'
                    .'|(*:92)'
                .')'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:128)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        29 => [[['_route' => 'app_categorie_show', '_controller' => 'App\\Controller\\CategorieController::show'], ['idCategorie'], ['GET' => 0], null, false, true, null]],
        41 => [[['_route' => 'app_categorie_edit', '_controller' => 'App\\Controller\\CategorieController::edit'], ['idCategorie'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        48 => [[['_route' => 'app_categorie_delete', '_controller' => 'App\\Controller\\CategorieController::delete'], ['idCategorie'], ['POST' => 0], null, false, true, null]],
        73 => [[['_route' => 'app_velo_show', '_controller' => 'App\\Controller\\VeloController::show'], ['idVelo'], ['GET' => 0], null, false, true, null]],
        85 => [[['_route' => 'app_velo_edit', '_controller' => 'App\\Controller\\VeloController::edit'], ['idVelo'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        92 => [[['_route' => 'app_velo_delete', '_controller' => 'App\\Controller\\VeloController::delete'], ['idVelo'], ['POST' => 0], null, false, true, null]],
        128 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
